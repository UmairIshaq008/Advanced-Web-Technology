import React, { useState, useEffect } from 'react'
import TaskList from './components/TaskList'
import AddTask from './components/AddTask'
import './App.css'

const App = () => {
  const [tasks, setTasks] = useState([])

  useEffect(() => {
    const savedTasks = JSON.parse(localStorage.getItem('tasks')) || []
    console.log('Loaded tasks from localStorage:', savedTasks)
    setTasks(savedTasks)
  }, [])

  useEffect(() => {
    console.log('Saving tasks to localStorage:', tasks)
    localStorage.setItem('tasks', JSON.stringify(tasks))
  }, [tasks])

  const addTask = (task) => {
    setTasks([...tasks, task])
  }

  const deleteTask = (id) => {
    setTasks(tasks.filter((task) => task.id !== id))
  }

  const toggleComplete = (id) => {
    setTasks(
      tasks.map((task) =>
        task.id === id ? { ...task, completed: !task.completed } : task
      )
    )
  }

  const editTask = (id, newText, newPriority) => {
    setTasks(
      tasks.map((task) =>
        task.id === id
          ? { ...task, text: newText, priority: newPriority }
          : task
      )
    )
  }

  const clearCompleted = () => {
    setTasks(tasks.filter((task) => !task.completed))
  }

  const sortTasks = (tasks) => {
    const priorityMap = { High: 1, Medium: 2, Low: 3 }
    return [...tasks].sort(
      (a, b) => priorityMap[a.priority] - priorityMap[b.priority]
    )
  }

  return (
    <div className="App bg-gray-100 min-h-screen p-6">
      <h1 className="text-3xl font-bold text-center mb-6">To-Do List</h1>
      <AddTask addTask={addTask} />
      <TaskList
        tasks={sortTasks(tasks)}
        deleteTask={deleteTask}
        toggleComplete={toggleComplete}
        editTask={editTask}
      />
      <button
        onClick={clearCompleted}
        className="mt-4 bg-red-500 text-white py-2 px-4 rounded hover:bg-red-700 transition duration-300"
      >
        Clear Completed
      </button>
    </div>
  )
}

export default App
