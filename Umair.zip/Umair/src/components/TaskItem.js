import React, { useState } from 'react'

const TaskItem = ({ task, deleteTask, toggleComplete, editTask }) => {
  const [isEditing, setIsEditing] = useState(false)
  const [newText, setNewText] = useState(task.text)
  const [newPriority, setNewPriority] = useState(task.priority)

  const handleEdit = () => {
    setIsEditing(true)
  }

  const handleSave = () => {
    editTask(task.id, newText, newPriority)
    setIsEditing(false)
  }

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      handleSave()
    }
  }

  return (
    <li
      onDoubleClick={handleEdit}
      className="bg-white p-4 rounded shadow mb-2 flex items-center justify-between hover:bg-gray-100 transition duration-300"
    >
      {isEditing ? (
        <>
          <input
            type="text"
            value={newText}
            onChange={(e) => setNewText(e.target.value)}
            onKeyDown={handleKeyDown}
            className="p-2 border rounded mr-2"
          />
          <select
            value={newPriority}
            onChange={(e) => setNewPriority(e.target.value)}
            className="p-2 border rounded mr-2"
          >
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>
          <button
            onClick={handleSave}
            className="bg-green-500 text-white py-2 px-4 rounded hover:bg-green-700 transition duration-300"
          >
            Save
          </button>
        </>
      ) : (
        <>
          <div className="flex items-center">
            <input
              type="checkbox"
              checked={task.completed}
              onChange={() => toggleComplete(task.id)}
              className="mr-2"
            />
            <span
              className={`flex-1 ${task.completed ? 'line-through' : ''}`}
              title="Double-click to edit"
            >
              {task.text} ({task.priority})
            </span>
          </div>
          <button
            onClick={() => deleteTask(task.id)}
            className="bg-red-500 text-white py-2 px-4 rounded hover:bg-red-700 transition duration-300"
          >
            Delete
          </button>
        </>
      )}
    </li>
  )
}

export default TaskItem
