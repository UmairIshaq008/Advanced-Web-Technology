import React, { useState } from 'react'

const AddTask = ({ addTask }) => {
  const [taskText, setTaskText] = useState('')
  const [priority, setPriority] = useState('Medium')

  const handleSubmit = (e) => {
    e.preventDefault()
    if (taskText.trim()) {
      addTask({ id: Date.now(), text: taskText, completed: false, priority })
      setTaskText('')
      setPriority('Medium')
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col items-center">
      <input
        type="text"
        value={taskText}
        onChange={(e) => setTaskText(e.target.value)}
        placeholder="Add a new task"
        className="mb-2 p-2 border rounded w-full max-w-md"
      />
      <div className="flex items-center mb-4">
        <select
          value={priority}
          onChange={(e) => setPriority(e.target.value)}
          className="p-2 border rounded"
        >
          <option value="High">High</option>
          <option value="Medium">Medium</option>
          <option value="Low">Low</option>
        </select>
        <button
          type="submit"
          className="ml-2 bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-700 transition duration-300"
        >
          Add Task
        </button>
      </div>
    </form>
  )
}

export default AddTask
