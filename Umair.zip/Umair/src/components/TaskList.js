import React from 'react'
import { TransitionGroup, CSSTransition } from 'react-transition-group'
import TaskItem from './TaskItem'
import './TaskList.css'

const TaskList = ({ tasks, deleteTask, toggleComplete, editTask }) => {
  return (
    <TransitionGroup component="ul" className="w-full max-w-md mx-auto">
      {tasks.map((task) => (
        <CSSTransition key={task.id} timeout={500} classNames="task">
          <TaskItem
            task={task}
            deleteTask={deleteTask}
            toggleComplete={toggleComplete}
            editTask={editTask}
          />
        </CSSTransition>
      ))}
    </TransitionGroup>
  )
}

export default TaskList
